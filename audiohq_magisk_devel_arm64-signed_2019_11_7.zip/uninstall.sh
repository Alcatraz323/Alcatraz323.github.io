mount -o remount,rw /system
mv /sdcard/audiohq_backups/audioserver.rc /system/etc/init
