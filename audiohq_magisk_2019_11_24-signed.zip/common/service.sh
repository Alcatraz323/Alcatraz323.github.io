#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

CFG_DIR="/data/misc/audioserver/boot.prof"

BOOT=$(cat $CFG_DIR)
BOOT_SWITCH=$(echo $BOOT | cut -d ";" -f1)
BOOT_TYPE=$(echo $BOOT | cut -d ";" -f2)

if [ $BOOT_SWITCH = "true" ]; then
    mkdir /data/data/io.alcatraz.audiohq/files/native_output/
    touch /data/data/io.alcatraz.audiohq/files/native_output/server.log
    nohup audiohq -d $BOOT_TYPE > /data/data/io.alcatraz.audiohq/files/native_output/server.log &
fi
# This script will be executed in late_start service mode
